<?php

namespace App\Models;

use App\Models\user;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class order extends Model
{
    protected $table = 'order';
    protected $fillable = ['user_id','name'];

    public function user(){
        // return $this->belongsToMany('App\Models\user',  'role');
        return $this->belongsTo(user::class);
    }
    

    use HasFactory;
}
