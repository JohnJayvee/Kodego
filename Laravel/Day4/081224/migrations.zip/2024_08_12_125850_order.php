<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        //
        Schema::create('order', function(Blueprint $table){
            $table->id();          
           // $table->foreignId('user_id');
           // $table->string('name');

           $table->unsignedBigInteger('user_id');
           $table->unsignedBigInteger('role_id');
           
          // $table->unsignedBigInteger('order_id');
           
           $table->foreign('role_id')->references('id')->on('role')->onDelete('cascade');
           $table->foreign('user_id')->references('id')->on('user')->onDelete('cascade');
           //$table->foreign('order_id')->references('id')->on('order')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
