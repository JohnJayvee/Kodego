<?php

namespace App\Http\Controllers;


use App\Models\Sample_Model;
use Illuminate\Http\Request;

class Sample_Controller extends Controller
{
    //


 

    
    


    public function index(){
      $data = Sample_Model::all(); 
      

        $data = Sample_Model::select('sample_tbl.*', 'second_tbl.role')
        ->join('second_tbl', 'sample_tbl.email', '=', 'second_tbl.email')
        ->get();

        // $data = Sample_Model::with('email')->get(); 
        // return $data;

    }

    public function store(Request $request){

        $data = Sample_Model::create([
            'name' => $request->name,
            'email' => $request->email,
            'pic' => $request->pic_name
            
        ]);

        $img = $request->file('pic');
        $img_name = $img->getClientOriginalName();
        $img->storeAs('images/', $img_name, 'public');

       

        if($data){
            return response()->json([
                'status' => 200,
                'data' => 'success'
            ]);

        }else{
            return response()->json([
                'status' => 404,
                'data' => "failed"
            ]);
        }

    }

    public function edit(Request $request, int $id){
        $data = Sample_Model::find($id);

        if($data){
                $data->update([
                    'name' => $request->name,
                    'email' => $request->email
                ]);

            return response()->json([
                'status' => 200,
                'data' => 'updated successfully'
            ]);
        }else{
            return response()->json([
                         'status' => 404,
                         'data' => "failed"
                     ]);
        }

    }


    public function destroy(Request $request, int $id){
        
        $data = Sample_Model::find($id);       


        if($data){
            $data->delete();
            $new_data = Sample_Model::all();

        return response()->json([
            'status' => 200,
            'mess' => 'deleted successfully',
            'data' => $new_data
        ]);
        }else{
        return response()->json([
                        'status' => 404,
                        'mess' => "failed to delete"
        ]);
        }

        

    }
}
