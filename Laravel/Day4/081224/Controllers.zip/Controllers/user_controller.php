<?php

namespace App\Http\Controllers;

use App\Models\role;
use App\Models\user;
use App\Models\order;
use Illuminate\Http\Request;

class user_controller extends Controller
{
    //
    

    public function index(){
        $data = order::with(['user.role'])->get(); 
        //order::with('user')
       
        return $data;
        

  
        //   $data = Sample_Model::select('sample_tbl.*', 'second_tbl.role')->join('second_tbl', 'sample_tbl.email', '=', 'second_tbl.email')->get();
  
          // $data = Sample_Model::with('email')->get(); 
          // return $data;
  
      }
}
